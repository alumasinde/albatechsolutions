(function(){'use strict';
 document.addEventListener('DOMContentLoaded',function(){
   var icon=document.getElementById('icon'), preview=document.getElementById('icon-preview');
   if(icon&&preview){var render=function(){var name=(icon.value||'fa-briefcase').trim().replace(/[^a-z0-9- ]/gi,'').split(/\s+/).filter(Boolean); var i=preview.querySelector('i'); i.className='fa-solid '+(name.join(' ')||'fa-briefcase');}; icon.addEventListener('input',render); render();}
   var priceType=document.getElementById('price_type'), price=document.getElementById('price');
   function syncPrice(){if(!priceType||!price)return; var quote=priceType.value==='quote'; price.disabled=quote; if(quote) price.value='';}
   if(priceType){priceType.addEventListener('change',syncPrice);syncPrice();}
   var form=document.querySelector('.admin-service-form'); if(form){form.addEventListener('submit',function(){var input=document.getElementById('content-input'), editor=document.querySelector('#editor .ql-editor'); if(input&&editor)input.value=editor.innerHTML;});}
 });
})();
