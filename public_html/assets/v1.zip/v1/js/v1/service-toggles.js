/*
 * AlbaTech — service list controls
 * Progressive enhancement for Active/Homepage toggle forms.
 * The server remains the source of truth; this script only adds busy state
 * and prevents accidental double submissions.
 */
(function () {
    'use strict';

    function markSaving(form) {
        var control = form && form.querySelector('.service-toggle');
        if (!control || control.disabled) return;

        control.classList.add('is-saving');
        control.setAttribute('aria-busy', 'true');

        var submit = form.querySelector('button[type="submit"], input[type="submit"]');
        if (submit) submit.disabled = true;
    }

    document.addEventListener('submit', function (event) {
        var form = event.target.closest('.service-toggle-form');
        if (form) markSaving(form);
    });

    document.addEventListener('keydown', function (event) {
        var control = event.target.closest('.service-toggle');
        if (!control || control.disabled) return;

        if (event.key === 'Enter' || event.key === ' ') {
            var form = control.closest('form');
            if (form && event.key === ' ') {
                event.preventDefault();
                control.click();
            }
        }
    });
})();
